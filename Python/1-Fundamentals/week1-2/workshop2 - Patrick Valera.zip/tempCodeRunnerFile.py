chine ===          ")
# name = input("Enter name to register: ")
# pin = input("Enter PIN: ")
# balance=0
# print(f'{name} has been registered with a starting 